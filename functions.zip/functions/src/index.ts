import * as functions from 'firebase-functions';
import { geocodeRequest } from './geocode';
import { placesRequest } from './places';

// // Start writing Firebase Functions
// // https://firebase.google.com/docs/functions/typescript

/* export const helloWorld = functions.https.onRequest((request, response) => {
  functions.logger.info('Hello logs!', { structuredData: true });
  response.send('Hello from Firebase!');
}); */

exports.geocode = functions.https.onRequest((request, response) => {
  geocodeRequest(request, response);
});

exports.placesNearby = functions.https.onRequest((request, response) => {
  placesRequest(request, response);
});
