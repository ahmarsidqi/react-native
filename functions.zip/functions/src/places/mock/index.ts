import antwerp from './antwerp';
// import chicago from './chicago';
// import toronto from './toronto';
// import san_francisco from './san_francisco';

export const mocks = {
  '51.219448,4.402464': antwerp,
  // '43.653225,-79.383186': toronto,
  // '41.878113,-87.629799': chicago,
  // '37.7749295,-122.4194155': san_francisco,
};

export type MocksLocations = keyof typeof mocks;

type MockResults = {
  business_status?: string;
  geometry: {
    location: {
      lat: number;
      lng: number;
    };
    viewport: {
      northeast: {
        lat: number;
        lng: number;
      };
      southwest: {
        lat: number;
        lng: number;
      };
    };
  };
  icon: string;
  name: string;
  opening_hours: {
    open_now: boolean;
  };
  photos?: string[];
  place_id: string;
  rating: number;
  reference: string;
  scope?: string;
  types?: string[];
  user_ratings_total: number;
  vicinity: string;
};

const mockImages = [
  'https://www.foodiesfeed.com/wp-content/uploads/2019/06/top-view-for-box-of-2-burgers-home-made-600x899.jpg',
  'https://www.foodiesfeed.com/wp-content/uploads/2019/04/mae-mu-oranges-ice-600x750.jpg',
  'https://www.foodiesfeed.com/wp-content/uploads/2020/08/detail-of-pavlova-strawberry-piece-of-cake-600x800.jpg',
  'https://www.foodiesfeed.com/wp-content/uploads/2019/04/mae-mu-baking-600x750.jpg',
  'https://www.foodiesfeed.com/wp-content/uploads/2019/04/mae-mu-pancakes-600x750.jpg',
  'https://www.foodiesfeed.com/wp-content/uploads/2019/02/messy-pizza-on-a-black-table-600x400.jpg',
  'https://www.foodiesfeed.com/wp-content/uploads/2019/02/pizza-ready-for-baking-600x400.jpg',
];

export const addMockImage = (restaurant: MockResults): MockResults => {
  const currentRestaurant = restaurant;
  const randomImage =
    mockImages[Math.ceil(Math.random() * (mockImages.length - 1))];
  currentRestaurant.photos = [randomImage];
  return currentRestaurant;
};
