import * as url from 'url';
import { Request, Response } from 'firebase-functions';

import { mocks, MocksLocations, addMockImage } from './mock';

export const placesRequest = (request: Request, response: Response): void => {
  const { location } = url.parse(request.url, true).query;
  const data = mocks[location as MocksLocations];
  let res = { results: {} };
  if (data) {
    res = { ...data };
    res.results = data.results.map(addMockImage);
  }

  response.json(res);
};
