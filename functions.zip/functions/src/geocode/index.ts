import * as url from 'url';
import { Request, Response } from 'firebase-functions';
import { locations as locationsMock } from './geocode.mock';

export const geocodeRequest = (request: Request, response: Response): void => {
  const { city } = url.parse(request.url, true).query;
  const locationMock = city
    ? locationsMock[city.toString().toLowerCase() as keyof typeof locationsMock]
    : {};

  response.json(locationMock);
};
